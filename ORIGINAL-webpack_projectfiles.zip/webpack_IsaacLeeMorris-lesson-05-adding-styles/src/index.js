import "./styles.scss";
import loadDropDown from "./loadDropDown";

console.info("Hello, webpack");
loadDropDown();
